/* eslint-disable no-undef */
const books = [];

module.exports = books;
